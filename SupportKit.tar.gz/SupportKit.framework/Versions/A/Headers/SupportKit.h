//
//  SupportKit.h
//  SupportKit
//  version : 0.1
//
//  Created by Michael Spensieri on 11/11/13.
//  Copyright (c) 2013 Radialpoint. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface SupportKit : NSObject

/**
 *  Description
 *
 *  @param controller controller description
 *  @param domain     domain description
 */

+(void)showInViewController:(UIViewController*)controller withZendeskURL:(NSString*)domain;

/**
 *  Description
 *
 *  @param controller controller description
 *  @param domain     domain description
 *  @param ticketUrl  ticketUrl description
 */
+(void)showInViewController:(UIViewController *)controller withZendeskURL:(NSString *)domain andTicketUrl: (NSString *)ticketUrl;

@end
